#ifndef ADT_H
#define ADT_H

// TODO
// define your ADTs here
#include <cstring>
#include <string>
using namespace std;

enum Choice{
	lamborghini, bugatti, ferrari, zenvo,
	trevita, mclaren, mercedes
};


struct Date{
	static const int NAME_SIZE = 100;

	char pro[NAME_SIZE];
	int year;
};


struct Car{
	static const int NAME_SIZE = 100;

	char object[NAME_SIZE];
	Date year;
	int mph;
	char msg[NAME_SIZE];
	Choice car[2];
};

#endif
