#include "fileFuncs.h"
#include <iostream>
using namespace std;

int main() {
    // variables
    int userChoice = 0;

    // menu loop
    do {
        // display menu
        cout << "1. Load a structure\n";
        cout << "2. Save a structure\n";
        cout << "3. Exit\n";

        // prompt and store, checking for bad input
        while (true) {
            cout << "Enter your choice: ";
            cin >> userChoice;

            if (cin.fail()) {
                cin.clear();
                cin.ignore(4096, '\n');
            }
            else {
                break;
            }
        }

        // branch
        if (userChoice == 1) {
            loadFile();
        }
        else if (userChoice == 2) {
            saveFile();
        }
        else if (userChoice != 3) {
            cout << "Invalid choice!\n";
        }
    } while (userChoice != 3);

    // terminate
    return 0;
}
