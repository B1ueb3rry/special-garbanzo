#include "adtFuncs.h"
#include "fileFuncs.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void loadFile() {
    // variables
    fstream inputFile;
    string filename = "", line = "";

    // prompt and store the filename
    cout << "Enter the filename with extension that you want to load:\n";
    cin.ignore();
    getline(cin, filename);

    // try opening the file
    inputFile.open(filename, ios::in | ios::binary);
    if (inputFile.fail()) {
        cout << "Error, unable to open that file!\n";
        return;
    }

    // load the data to a structure
    // TODO
    Car user_car;
    inputFile.read(reinterpret_cast<char*>(&user_car), sizeof(user_car));


    // display its data
    // TODO
    cout << convert(user_car) << endl;

    // close the file
    inputFile.close();
}

void saveFile() {
    // variables
    fstream outputFile;
    string filename = "";

    // prompt and store the filename
    cout << "Enter the filename with extension that you want to use:\n";
    cin.ignore();
    getline(cin, filename);

    // try opening the file
    outputFile.open(filename, ios::out | ios::binary);
    if (outputFile.fail()) {
        cout << "Error, unable to open that file!\n";
        return;
    }

    // create the structure using the user's information
    // TODO
    Car vehicle = car_info();


    // save the structure to the binary file
    // TODO
   	outputFile.write(reinterpret_cast<char*>(&vehicle), sizeof(vehicle));

    // close the file
    outputFile.close();
}
