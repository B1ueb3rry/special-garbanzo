#ifndef FILE_FUNCS_H
#define FILE_FUNCS_H

// function prototypes
void loadFile();
void saveFile();

#endif
