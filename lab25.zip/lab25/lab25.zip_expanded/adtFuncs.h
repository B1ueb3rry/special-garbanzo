#ifndef ADT_FUNCS_H
#define ADT_FUNCS_H

#include "ADT.h"

// TODO
// function prototypes for your various convert and create functions
string convert(Choice);
Choice convert(string);
string convert(const Car&);
Car car_info();

#endif
