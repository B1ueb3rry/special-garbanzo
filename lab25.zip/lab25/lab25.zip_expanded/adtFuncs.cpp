#include "adtFuncs.h"

// TODO
// implement the functions from the header file
#include <cctype>
#include <iostream>
#include <string>
using namespace std;



Choice convert(string exp_cars){
	 for (unsigned i = 0; i < exp_cars.size(); i++) {
	        exp_cars[i] = tolower(exp_cars[i]);
	    }
	if (exp_cars == "lamborghini") return lamborghini;
	else if (exp_cars == "bugatti") return bugatti;
	else if (exp_cars == "ferrari") return ferrari;
	else if (exp_cars == "zenvo") return zenvo;
	else if (exp_cars == "trevita") return trevita;
	else if (exp_cars == "mclaren") return mclaren;
	else if (exp_cars == "mercedes") return mercedes;
	else {
		cout << "Invalid!\n";
		return lamborghini;
}
}


string convert(Choice exp_cars){
	switch(exp_cars){
	case lamborghini: return "lamborghini";
	case bugatti: return "bugatti";
	case ferrari: return "ferrari";
	case zenvo: return "zenvo";
	case trevita: return "trevita";
	case mclaren: return "mclaren";
	case mercedes: return "mercedes";
	default: return "lamborghini";
	}
}


string convert(const Car& rich_cars){
    string info = "\n********** CAR REPORT **********\n";
    string ufo;
    string company;
    string msg;

    ufo.insert(0, rich_cars.object);
    info += "Name: " + ufo + "\n";
    company.insert(0, rich_cars.year.pro);
    info += "Production Company: " + company + "\n";
	info += "Year it was made: " + to_string(rich_cars.year.year) + "\n";
	info += "Maximum miles per hour: " + to_string(rich_cars.mph) + "\n";
	msg.insert(0, rich_cars.msg);
	info += "Comment: " + msg + "\n";

    info += "Dream Car: " + convert(rich_cars.car[0])
         + " and " + convert(rich_cars.car[1]) + "\n";
    return info;
}

Car car_info(){

		Car review;
		string dream = "";

		cout << "Enter the name of the car: ";
		cin.getline(review.object, review.NAME_SIZE);

		cout << "Enter the year when it was created: ";
		cin >> review.year.year;
		cin.ignore();

		cout << "Enter the company that made it: ";
		cin.getline(review.year.pro, review.NAME_SIZE);

		cout << "Enter the maximum miles per hour: ";
		cin >> review.mph;
		cin.ignore();

		cout << "Enter an optional comment: ";
		cin.getline(review.msg, review.NAME_SIZE);

		cout << "Enter your dream car with the list of the following.\n";
		for(Choice c = lamborghini; c <= mercedes; c = Choice(c+1)){
			cout << '\t' << convert(c) << endl;
		}
		cout << endl;

		cout << "Enter your first dream car: ";
		cin.ignore();
		getline(cin, dream);
		review.car[0] = convert(dream);

		cout << "Enter your second dream car: ";
		getline(cin, dream);
		review.car[1] = convert(dream);
		return review;
}





